Load Generator README

The targets for each load generator should be listed in a targets.json file located
in the same directory as the loadGenerator.py file. It should contain a json object
with a 'targets' array with the target IPs listed as strings.

Each node being used as a target should have "initIperf.sh" run on them prior to the
test. This will launch two Iperf servers, one for UDP and one for TCP.

To run the load generator, use the command 

python ./loadGenerator.py <mode> <volume>

mode is one of the following:
cons: constant traffic
incr: increasing traffic
puls: pulsating traffic
rand: random traffic

volume should be a decimal number over 100 of the number of kilobits per second that
the load generator should create. 