iperf -s -p 2001 > /dev/null &
iperf -s -u -p 2002 > /dev/null &
